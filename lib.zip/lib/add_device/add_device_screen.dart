import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/device.dart';
import '../database/device_database.dart';

class AddDeviceScreen extends StatefulWidget {
  const AddDeviceScreen({super.key});

  @override
  State<AddDeviceScreen> createState() => _AddDeviceScreenState();
}

class _AddDeviceScreenState extends State<AddDeviceScreen> {
  final _formKey = GlobalKey<FormState>();

  final _orderCardController = TextEditingController();
  final _deviceNumberController = TextEditingController();
  final _deviceTypeController = TextEditingController();
  final _workTypeController = TextEditingController();
  final _customerNameController = TextEditingController();
  final _responsibleController = TextEditingController();

  DateTime? _dateReceived;
  DateTime? _plannedShipmentDate;

  Future<void> _pickDate(BuildContext context, bool isReceivedDate) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
    );
    if (selected != null) {
      setState(() {
        if (isReceivedDate) {
          _dateReceived = selected;
        } else {
          _plannedShipmentDate = selected;
        }
      });
    }
  }

  void _saveDevice() async {
    if (!_formKey.currentState!.validate() || _dateReceived == null || _plannedShipmentDate == null) return;

    final device = Device(
      orderCardNumber: _orderCardController.text,
      deviceNumber: _deviceNumberController.text,
      deviceType: _deviceTypeController.text,
      workType: _workTypeController.text,
      customerName: _customerNameController.text,
      dateReceived: _dateReceived!,
      plannedShipmentDate: _plannedShipmentDate!,
      responsiblePerson: _responsibleController.text,
    );

    await DeviceDatabase.instance.insertDevice(device);

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _orderCardController.dispose();
    _deviceNumberController.dispose();
    _deviceTypeController.dispose();
    _workTypeController.dispose();
    _customerNameController.dispose();
    _responsibleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Добавление прибора'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveDevice,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(children: [
            TextFormField(
              controller: _orderCardController,
              decoration: const InputDecoration(labelText: 'Номер карты заказа'),
              validator: (v) => v == null || v.isEmpty ? 'Введите номер' : null,
            ),
            TextFormField(
              controller: _deviceNumberController,
              decoration: const InputDecoration(labelText: 'Номер прибора'),
              validator: (v) => v == null || v.isEmpty ? 'Введите номер' : null,
            ),
            TextFormField(
              controller: _deviceTypeController,
              decoration: const InputDecoration(labelText: 'Тип прибора'),
              validator: (v) => v == null || v.isEmpty ? 'Введите тип' : null,
            ),
            TextFormField(
              controller: _workTypeController,
              decoration: const InputDecoration(labelText: 'Тип работ'),
              validator: (v) => v == null || v.isEmpty ? 'Введите тип работ' : null,
            ),
            TextFormField(
              controller: _customerNameController,
              decoration: const InputDecoration(labelText: 'Наименование заказчика'),
              validator: (v) => v == null || v.isEmpty ? 'Введите заказчика' : null,
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: InkWell(
                  onTap: () => _pickDate(context, true),
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'Дата поступления на ИС'),
                    child: Text(_dateReceived != null
                        ? DateFormat('dd.MM.yyyy').format(_dateReceived!)
                        : 'Выберите дату'),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: InkWell(
                  onTap: () => _pickDate(context, false),
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'Планируемая дата отгрузки'),
                    child: Text(_plannedShipmentDate != null
                        ? DateFormat('dd.MM.yyyy').format(_plannedShipmentDate!)
                        : 'Выберите дату'),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            TextFormField(
              controller: _responsibleController,
              decoration: const InputDecoration(labelText: 'Ответственный'),
              validator: (v) => v == null || v.isEmpty ? 'Введите имя' : null,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
              child: const Text('Отмена'),
            )
          ]),
        ),
      ),
    );
  }
}
