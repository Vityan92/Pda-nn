class Device {
  final int? id;
  final String orderCardNumber;
  final String deviceNumber;
  final String deviceType;
  final String workType;
  final String customerName;
  final DateTime dateReceived;
  final DateTime plannedShipmentDate;
  final String responsiblePerson;

  Device({
    this.id,
    required this.orderCardNumber,
    required this.deviceNumber,
    required this.deviceType,
    required this.workType,
    required this.customerName,
    required this.dateReceived,
    required this.plannedShipmentDate,
    required this.responsiblePerson,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'orderCardNumber': orderCardNumber,
    'deviceNumber': deviceNumber,
    'deviceType': deviceType,
    'workType': workType,
    'customerName': customerName,
    'dateReceived': dateReceived.toIso8601String(),
    'plannedShipmentDate': plannedShipmentDate.toIso8601String(),
    'responsiblePerson': responsiblePerson,
  };

  factory Device.fromMap(Map<String, dynamic> map) => Device(
    id: map['id'],
    orderCardNumber: map['orderCardNumber'],
    deviceNumber: map['deviceNumber'],
    deviceType: map['deviceType'],
    workType: map['workType'],
    customerName: map['customerName'],
    dateReceived: DateTime.parse(map['dateReceived']),
    plannedShipmentDate: DateTime.parse(map['plannedShipmentDate']),
    responsiblePerson: map['responsiblePerson'],
  );

  Device copyWith({
    int? id,
    String? orderCardNumber,
    String? deviceNumber,
    String? deviceType,
    String? workType,
    String? customerName,
    DateTime? dateReceived,
    DateTime? plannedShipmentDate,
    String? responsiblePerson,
  }) {
    return Device(
      id: id ?? this.id,
      orderCardNumber: orderCardNumber ?? this.orderCardNumber,
      deviceNumber: deviceNumber ?? this.deviceNumber,
      deviceType: deviceType ?? this.deviceType,
      workType: workType ?? this.workType,
      customerName: customerName ?? this.customerName,
      dateReceived: dateReceived ?? this.dateReceived,
      plannedShipmentDate: plannedShipmentDate ?? this.plannedShipmentDate,
      responsiblePerson: responsiblePerson ?? this.responsiblePerson,
    );
  }
}
