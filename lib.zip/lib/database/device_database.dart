import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/device.dart';

class DeviceDatabase {
  static final DeviceDatabase instance = DeviceDatabase._init();

  static Database? _database;

  DeviceDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB('devices.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const textType = 'TEXT NOT NULL';

    await db.execute('''
      CREATE TABLE devices (
        id $idType,
        orderCardNumber $textType,
        deviceNumber $textType,
        deviceType $textType,
        workType $textType,
        customerName $textType,
        dateReceived $textType,
        plannedShipmentDate $textType,
        responsiblePerson $textType
      )
    ''');
  }

  Future<Device> insertDevice(Device device) async {
    final db = await instance.database;
    final id = await db.insert('devices', device.toMap());
    return device.copyWith(id: id);
  }

  Future<List<Device>> getAllDevices() async {
    final db = await instance.database;
    final result = await db.query('devices', orderBy: 'id DESC');

    return result.map((map) => Device.fromMap(map)).toList();
  }

  Future<int> updateDevice(Device device) async {
    final db = await instance.database;
    return db.update(
      'devices',
      device.toMap(),
      where: 'id = ?',
      whereArgs: [device.id],
    );
  }

  Future<int> deleteDevice(int id) async {
    final db = await instance.database;
    return await db.delete(
      'devices',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
