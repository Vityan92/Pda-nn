import 'package:flutter/material.dart';
import '../../models/device.dart';
import '../../device_passport/device_passport_screen.dart';

class DeviceCard extends StatelessWidget {
  final Device device;
  final void Function(String) onDeviceTypeChanged;
  final VoidCallback onDelete;

  const DeviceCard({
    super.key,
    required this.device,
    required this.onDeviceTypeChanged,
    required this.onDelete,
  });

  static const Map<String, String> deviceIcons = {
    'ПГХ-1000': 'assets/images/PGC_1000.png',
    'ПГХ-1000.1 исп.1': 'assets/images/PGC_1000.1_1.png',
    'ПГХ-1000.1 исп.2': 'assets/images/PGC_1000.1_2.png',
  };

  @override
  Widget build(BuildContext context) {
    final path = deviceIcons[device.deviceType] ?? '';
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DevicePassportScreen(device: device)),
        );
      },
      onLongPress: () {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Действия с прибором'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  onDelete();
                },
                child: const Text('Удалить', style: TextStyle(color: Colors.red)),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Редактировать'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Отмена'),
              ),
            ],
          ),
        );
      },
      child: Card(
        elevation: 4,
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              GestureDetector(
                onTap: () async {
                  final selected = await showDialog<String>(
                    context: context,
                    builder: (_) => SimpleDialog(
                      title: const Text('Выберите тип прибора'),
                      children: deviceIcons.keys.map((t) {
                        return SimpleDialogOption(
                          onPressed: () => Navigator.pop(context, t),
                          child: Row(
                            children: [
                              Image.asset(deviceIcons[t]!, width: 32, height: 32),
                              const SizedBox(width: 8),
                              Text(t),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  );
                  if (selected != null && selected != device.deviceType) {
                    onDeviceTypeChanged(selected);
                  }
                },
                child: path.isNotEmpty
                    ? Image.asset(path, width: 64, height: 64)
                    : const Icon(Icons.device_unknown, size: 64),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Карта заказа: ${device.orderCardNumber}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('Номер прибора: ${device.deviceNumber}'),
                    Text('Тип: ${device.deviceType}'),
                    Text('Работы: ${device.workType}'),
                    Text('Заказчик: ${device.customerName}'),
                    Text('Поступление: ${_fmt(device.dateReceived)}'),
                    Text('Отгрузка: ${_fmt(device.plannedShipmentDate)}'),
                    Text('Ответственный: ${device.responsiblePerson}'),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  String _fmt(DateTime d) => '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';
}
