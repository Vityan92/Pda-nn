import 'package:flutter/material.dart';
import '../models/device.dart';
import '../home_page/device_card.dart';
import '../database/device_database.dart';

class DeviceList extends StatefulWidget {
  const DeviceList({super.key});

  @override
  State<DeviceList> createState() => _DeviceListState();
}

class _DeviceListState extends State<DeviceList> {
  List<Device> _devices = [];

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    final devices = await DeviceDatabase.instance.getAllDevices();
    setState(() {
      _devices = devices;
    });
  }

  Future<void> _onDeviceTypeChanged(Device device, String newType) async {
    final updatedDevice = device.copyWith(deviceType: newType);
    await DeviceDatabase.instance.updateDevice(updatedDevice);
    _loadDevices();
  }

  Future<void> _onDelete(Device device) async {
    await DeviceDatabase.instance.deleteDevice(device.id!);
    _loadDevices();
  }

  @override
  Widget build(BuildContext context) {
    if (_devices.isEmpty) {
      return const Center(
        child: Text('Нет добавленных приборов'),
      );
    }

    return ListView.builder(
      itemCount: _devices.length,
      itemBuilder: (context, index) {
        final device = _devices[index];
        return GestureDetector(
          onTap: () {
            Navigator.pushNamed(
              context,
              '/device_passport',
              arguments: device,
            );
          },
          onLongPress: () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Выберите действие'),
                content: Text('Прибор: ${device.deviceNumber}'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _onDelete(device);
                    },
                    child: const Text('Удалить'),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                      // TODO: Переход на экран редактирования прибора
                    },
                    child: const Text('Редактировать'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Отмена'),
                  ),
                ],
              ),
            );
          },
          child: DeviceCard(
            device: device,
            onDeviceTypeChanged: (newType) =>
                _onDeviceTypeChanged(device, newType), onDelete: () {  },
          ),
        );
      },
    );
  }
}
