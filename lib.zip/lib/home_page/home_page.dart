import 'package:flutter/material.dart';
import '../add_device/add_device_screen.dart';
import 'app_bar_content.dart';
import 'device_list.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarContent(
        onSearchChanged: (query) {
          // передай строку в фильтр списка устройств
        },
      ),
      body: DeviceList(),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text("Добавить прибор"),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddDeviceScreen()),
          );
        },
      ),
    );
  }
}
