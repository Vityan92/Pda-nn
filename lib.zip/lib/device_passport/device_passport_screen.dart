import 'package:flutter/material.dart';
import '../models/device.dart';
import 'package:intl/intl.dart';

class DevicePassportScreen extends StatelessWidget {
  final Device device;

  const DevicePassportScreen({super.key, required this.device});

  String _fmt(DateTime d) => DateFormat('dd.MM.yyyy').format(d);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Паспорт прибора')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            _row('Номер карты заказа', device.orderCardNumber),
            _row('Номер прибора', device.deviceNumber),
            _row('Тип прибора', device.deviceType),
            _row('Тип работ', device.workType),
            _row('Наименование заказчика', device.customerName),
            _row('Дата поступления', _fmt(device.dateReceived)),
            _row('Планируемая дата отгрузки', _fmt(device.plannedShipmentDate)),
            _row('Ответственный', device.responsiblePerson),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      children: [
        Expanded(flex: 2, child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold))),
        Expanded(flex: 3, child: Text(value)),
      ],
    ),
  );
}
